PASSWORD = 'P@55W06D@12y' # You can modify your instance password here
SG_NAME = 'FOREC2'        # You can modify your Security Group Name here
IN_TYPE = 't2.micro'      # You can modify your instance type here
IN_SIZE = '10'            # You can modify your instance size here
